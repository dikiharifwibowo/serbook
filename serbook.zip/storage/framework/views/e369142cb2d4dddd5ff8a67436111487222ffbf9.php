<br><br><br>
    <?php $__env->startSection('content'); ?>
    <!--Content-->
    <div class="container">
        <div class="row">
            <div class="card" style="display: inline; height: 50px; width: 100%; padding: 5px;">
             
                <?php foreach ($categorynav as $cat) { ?>
              
                    <b> <a href="<?php echo e(url('category/'.$cat->category)); ?>"> <?php echo e($cat->category); ?> </a> / </b>

                <?php } ?>
            
            </div>
        </div>
        <br>
        <li class="nav nav-item">
            <form class="nav-link" action="<?php echo e(url('search')); ?>" method="post" style="margin: 0px; padding: 0px;">
                    <?php echo e(csrf_field()); ?>

            <input type="search" style="background: #ededed url('<?php echo e(asset('theme/img/sprite-hm.png')); ?>') no-repeat 8px -58px;" id="search1" name="provinsi" placeholder="Semua Provinsi"  data-toggle="modal" data-target="#myModal">
            <input type="search" name="search" placeholder="2.569.870 Buku di Sekitar Anda">
            <button class="btn btn-primary" style="height: 50px; -webkit-border-radius: 10em;
                        -moz-border-radius: 10em;
                        border-radius: 10em;">Cari</button>
            </form>
        </li>
        <hr> 
        <?php if(Request::segment(2) === null): ?>
            <h2 align="center">Pencarian berdasarkan "<?php echo e($cari); ?>"</h2>
        <?php else: ?>
            <h2 align="center">Buku Berdasarkan  "<?php echo e(Request::segment(2)); ?>"</h2>
        <?php endif; ?>  
        <hr>
        <div class="row">
             <div class="col-lg-12">
                <div class="row">
                   <?php foreach ($category as $post) { ?>
                    <div class="col-lg-2" style="margin-bottom: 20px;">
                        <div class="card" style="height: 400px;">

                        <!--Card image-->
                        <div class="view overlay hm-white-slight">
                        	<a href="<?php echo e(url('/'.$post['judul'])); ?>">
	                            <img style="height: 230px; width: 100%;" src="<?php echo e(asset('img/iklan/'.$post['cover'])); ?>" class="img-fluid" alt="">
	                            <p align="center" style="margin: 10px;">
	                            <b style="" class="card-title"><strong><?php echo substr(strip_tags($post['judul']),0,100); ?></strong></b>
	                            <p style="margin: 2px;" align="center">Rp. 70.000</p><br>
                                <p style="margin: 2px;" align="center"><?php echo e($post['provinsi']); ?></p>
                            </a>
                        </p>
                        </div>
  						
                        </div>
                        <!--/.Card-->
                    </div>
                    <?php } ?>
                </div>
             </div>
        </div>
    
    </div>
    <!--/.Content-->
<?php echo $__env->make('layouts.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>